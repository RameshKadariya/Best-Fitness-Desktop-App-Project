﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace fitnessProject.Classes
{
	public class customerTrainingPlan
	{
		SqlConnection conn = new SqlConnection(connectionClass.connectionString);
		public bool manageCustomerTrainingPlan(int ID, 
			int customerID, 
			int trainingPlanID, 
			int Units, 
			String remarks, 
			int Mode)
		{
			try
			{
				bool result = false;
				String txtSql = "";
				if (Mode ==1)
				{
					txtSql =@" insert into customerTrainingPlanTable(customerID,trainingPlanID,Units,remarks)
                             values (@customerID,@trainingPlanID,@Units,@remarks)";
				}
				if (Mode ==2)
					{
						txtSql =@"update customerTrainingPlanTable set customerID=@customerID,
                                   trainingPlanID=@trainingPlanID,Units=@Units,
                                    remarks=@remarks where ID =@ID";
					}
				if (Mode ==3)
				{
					txtSql =@"delete from customerTrainingPlanTable where ID=@ID";
				}
				SqlCommand cmd = new SqlCommand(txtSql, conn);
				cmd.CommandType = CommandType.Text;
				cmd.Parameters.AddWithValue("@ID", ID);
				cmd.Parameters.AddWithValue("@customerID", customerID);
				cmd.Parameters.AddWithValue("@trainingPlanID", trainingPlanID);
				cmd.Parameters.AddWithValue("@Units", Units);
				cmd.Parameters.AddWithValue("@remarks", remarks);
				conn.Open();
				int r = cmd.ExecuteNonQuery();
				if (r>0)
				{
					return true;
				}
				else 
					return false;

			
			}
			catch (Exception ex)
			{

				throw ex;
			}
		finally  {conn.Close();}
		}
		public DataTable allTrainigPlan()
		{
			try
			{
				DataTable dt = new DataTable();
				SqlCommand cmd = new SqlCommand(@"select ID, 
                                                customerName, 
                                                trainingPlanName,
                                                ct.Units,rate,
                                                Amount =ct.Units*rate,ct.remarks from customerTrainingPlanTable ct,
                                                trainingPlanTable t, 
                                                customerTable c where ct.trainingPlanID=t.trainingPlanID and ct.customerID =c.customerID", 
										 conn);
				//cmd.CommandType= CommandType.Text;
				//cmd.Parameters.AddWithValue("@customerID", customerID);
				conn.Open();
				SqlDataReader dr = cmd.ExecuteReader();
				dt.Load(dr);
				conn.Close();
				return dt;
			}
			catch (Exception ex)
			{

				throw ex;
			}
			finally { conn.Close(); }
		}
		//Displayig the data which are based on the customerID
		public DataTable getTrainingPlansByCustomerID(int customerID) 
		{
			try
			{
				DataTable dt = new DataTable();
				SqlCommand cmd = new SqlCommand(@"select ID, 
                                                customerName, 
                                                trainingPlanName,
                                                ct.Units,rate,
                                                Amount =ct.Units*rate from customerTrainingPlanTable ct,
                                                trainingPlanTable t, 
                                                customerTable c where ct.trainingPlanID=t.trainingPlanID and ct.customerID=c.customerID and
                                                c.customerID=@customerID", conn);
				cmd.CommandType= CommandType.Text;
				cmd.Parameters.AddWithValue("@customerID", customerID);
				conn.Open();
				SqlDataReader dr = cmd.ExecuteReader();
				dt.Load(dr);
				conn.Close();
				return dt;
			}
			catch (Exception ex)
			{

				throw ex;
			}
			finally { conn.Close(); }
		}
		 public DataTable getTrainingDetailsByName(string trainingPlanName)
		{
			try
			{
				DataTable dt = new DataTable();
				SqlCommand cmd = new SqlCommand(@"select ID, 
                                                customerName, 
                                                trainingPlanName,
                                                ct.Units,rate,
                                                Amount=ct.Units*rate from customerTrainingPlanTable ct,
                                                trainingPlanTable t, 
                                                customerTable c where ct.trainingPlanID=t.trainingPlanID and 
                                                ct.customerID=c.customerID and
                                                t.trainingPlanName=@trainingPlanName", conn);
				cmd.CommandType= CommandType.Text;
				cmd.Parameters.AddWithValue("@trainingPlanName",trainingPlanName);
				conn.Open();
				SqlDataReader dr = cmd.ExecuteReader();
				dt.Load(dr);
				conn.Close();
				return dt;
			}
			catch (Exception ex)
			{

				throw ex;
			}
			finally { conn.Close(); }
		}
		

	}
}
